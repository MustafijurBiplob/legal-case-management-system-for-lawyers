<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LMS_Admin {

    private $clients;
    private $cases;
    private $hearings;
    private $documents;
    private $invoices;

    public function __construct() {
        $this->clients   = new LMS_Clients();
        $this->cases     = new LMS_Cases();
        $this->hearings  = new LMS_Hearings();
        $this->documents = new LMS_Documents();
        $this->invoices  = new LMS_Invoices();

        add_action( 'admin_menu',             array( $this, 'register_menus' ) );
        add_action( 'admin_enqueue_scripts',  array( $this, 'enqueue_assets' ) );
        add_action( 'wp_ajax_lms_save_client',   array( $this, 'ajax_save_client' ) );
        add_action( 'wp_ajax_lms_delete_client', array( $this, 'ajax_delete_client' ) );
        add_action( 'wp_ajax_lms_save_case',     array( $this, 'ajax_save_case' ) );
        add_action( 'wp_ajax_lms_delete_case',   array( $this, 'ajax_delete_case' ) );
        add_action( 'wp_ajax_lms_save_hearing',  array( $this, 'ajax_save_hearing' ) );
        add_action( 'wp_ajax_lms_save_invoice',  array( $this, 'ajax_save_invoice' ) );
    }

    /* ----------------------------------------------------------------
       Menus
    ---------------------------------------------------------------- */
    public function register_menus() {
        add_menu_page(
            'Legal Management',
            'Legal Mgmt',
            'manage_options',
            'lms-dashboard',
            array( $this, 'page_dashboard' ),
            'dashicons-hammer',
            30
        );
        add_submenu_page( 'lms-dashboard', 'Dashboard',  'Dashboard',  'manage_options', 'lms-dashboard',  array( $this, 'page_dashboard' ) );
        add_submenu_page( 'lms-dashboard', 'Clients',    'Clients',    'manage_options', 'lms-clients',    array( $this, 'page_clients' ) );
        add_submenu_page( 'lms-dashboard', 'Cases',      'Cases',      'manage_options', 'lms-cases',      array( $this, 'page_cases' ) );
        add_submenu_page( 'lms-dashboard', 'Hearings',   'Hearings',   'manage_options', 'lms-hearings',   array( $this, 'page_hearings' ) );
        add_submenu_page( 'lms-dashboard', 'Documents',  'Documents',  'manage_options', 'lms-documents',  array( $this, 'page_documents' ) );
        add_submenu_page( 'lms-dashboard', 'Invoices',   'Invoices',   'manage_options', 'lms-invoices',   array( $this, 'page_invoices' ) );
    }

    /* ----------------------------------------------------------------
       Assets
    ---------------------------------------------------------------- */
    public function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'lms-' ) === false ) return;
        wp_enqueue_style(  'lms-admin', LMS_PLUGIN_URL . 'admin/css/admin.css', array(), LMS_VERSION );
        wp_enqueue_script( 'lms-admin', LMS_PLUGIN_URL . 'admin/js/admin.js',  array('jquery'), LMS_VERSION, true );
        wp_localize_script( 'lms-admin', 'LMS', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('lms_nonce'),
        ) );
    }

    /* ----------------------------------------------------------------
       Pages
    ---------------------------------------------------------------- */
    public function page_dashboard() {
        $total_clients  = $this->clients->count();
        $total_open     = $this->cases->count( array('status'=>'open') );
        $total_cases    = $this->cases->count();
        $upcoming       = $this->hearings->get_upcoming(5);
        $totals         = $this->invoices->get_totals();
        include LMS_PLUGIN_DIR . 'templates/dashboard.php';
    }

    public function page_clients() {
        $action  = $_GET['action'] ?? 'list';
        $id      = (int) ( $_GET['id'] ?? 0 );
        $client  = $id ? $this->clients->get( $id ) : null;
        $search  = sanitize_text_field( $_GET['s'] ?? '' );
        $clients = $this->clients->get_all( array( 'search' => $search ) );
        include LMS_PLUGIN_DIR . 'templates/clients.php';
    }

    public function page_cases() {
        $action  = $_GET['action'] ?? 'list';
        $id      = (int) ( $_GET['id'] ?? 0 );
        $case    = $id ? $this->cases->get( $id ) : null;
        $search  = sanitize_text_field( $_GET['s'] ?? '' );
        $status  = sanitize_key( $_GET['status'] ?? '' );
        $cases   = $this->cases->get_all( array( 'search' => $search, 'status' => $status ) );
        $clients_list = $this->clients->get_all( array('limit' => 500) );
        if ( $case ) {
            $hearings  = $this->hearings->get_by_case( $id );
            $documents = $this->documents->get_by_case( $id );
        }
        include LMS_PLUGIN_DIR . 'templates/cases.php';
    }

    public function page_hearings() {
        $upcoming = $this->hearings->get_upcoming(50);
        $cases_list = $this->cases->get_all( array('limit'=>500) );
        include LMS_PLUGIN_DIR . 'templates/hearings.php';
    }

    public function page_documents() {
        $cases_list = $this->cases->get_all( array('limit'=>500) );
        include LMS_PLUGIN_DIR . 'templates/documents.php';
    }

    public function page_invoices() {
        $status   = sanitize_key( $_GET['status'] ?? '' );
        $invoices = $this->invoices->get_all( array('status' => $status) );
        $totals   = $this->invoices->get_totals();
        $cases_list   = $this->cases->get_all( array('limit'=>500) );
        $clients_list = $this->clients->get_all( array('limit'=>500) );
        include LMS_PLUGIN_DIR . 'templates/invoices.php';
    }

    /* ----------------------------------------------------------------
       AJAX: Clients
    ---------------------------------------------------------------- */
    public function ajax_save_client() {
        check_ajax_referer( 'lms_nonce', 'nonce' );
        if ( ! current_user_can('manage_options') ) wp_send_json_error('Unauthorized');

        $id   = (int) ( $_POST['id'] ?? 0 );
        $data = $_POST;

        if ( $id ) {
            $result = $this->clients->update( $id, $data );
        } else {
            $result = $this->clients->insert( $data );
        }

        $result !== false ? wp_send_json_success( array('id' => $result ?: $id) ) : wp_send_json_error('Save failed');
    }

    public function ajax_delete_client() {
        check_ajax_referer( 'lms_nonce', 'nonce' );
        if ( ! current_user_can('manage_options') ) wp_send_json_error('Unauthorized');
        $id = (int) ( $_POST['id'] ?? 0 );
        $this->clients->delete( $id ) ? wp_send_json_success() : wp_send_json_error('Delete failed');
    }

    /* ----------------------------------------------------------------
       AJAX: Cases
    ---------------------------------------------------------------- */
    public function ajax_save_case() {
        check_ajax_referer( 'lms_nonce', 'nonce' );
        if ( ! current_user_can('manage_options') ) wp_send_json_error('Unauthorized');

        $id   = (int) ( $_POST['id'] ?? 0 );
        $data = $_POST;
        $result = $id ? $this->cases->update( $id, $data ) : $this->cases->insert( $data );
        $result !== false ? wp_send_json_success( array('id' => $result ?: $id) ) : wp_send_json_error('Save failed');
    }

    public function ajax_delete_case() {
        check_ajax_referer( 'lms_nonce', 'nonce' );
        if ( ! current_user_can('manage_options') ) wp_send_json_error('Unauthorized');
        $id = (int) ( $_POST['id'] ?? 0 );
        $this->cases->delete( $id ) ? wp_send_json_success() : wp_send_json_error('Delete failed');
    }

    /* ----------------------------------------------------------------
       AJAX: Hearings
    ---------------------------------------------------------------- */
    public function ajax_save_hearing() {
        check_ajax_referer( 'lms_nonce', 'nonce' );
        if ( ! current_user_can('manage_options') ) wp_send_json_error('Unauthorized');

        $id   = (int) ( $_POST['id'] ?? 0 );
        $data = $_POST;
        $result = $id ? $this->hearings->update( $id, $data ) : $this->hearings->insert( $data );
        $result !== false ? wp_send_json_success( array('id' => $result ?: $id) ) : wp_send_json_error('Save failed');
    }

    /* ----------------------------------------------------------------
       AJAX: Invoices
    ---------------------------------------------------------------- */
    public function ajax_save_invoice() {
        check_ajax_referer( 'lms_nonce', 'nonce' );
        if ( ! current_user_can('manage_options') ) wp_send_json_error('Unauthorized');

        $id   = (int) ( $_POST['id'] ?? 0 );
        $data = $_POST;
        $result = $id ? $this->invoices->update( $id, $data ) : $this->invoices->insert( $data );
        $result !== false ? wp_send_json_success( array('id' => $result ?: $id) ) : wp_send_json_error('Save failed');
    }
}
