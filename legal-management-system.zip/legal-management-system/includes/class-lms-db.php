<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LMS_DB {

    public static function create_tables() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Clients table
        $sql_clients = "CREATE TABLE {$wpdb->prefix}lms_clients (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            first_name   VARCHAR(100)    NOT NULL,
            last_name    VARCHAR(100)    NOT NULL,
            email        VARCHAR(150)    NOT NULL,
            phone        VARCHAR(30)     DEFAULT '',
            address      TEXT            DEFAULT '',
            nid          VARCHAR(50)     DEFAULT '',
            notes        TEXT            DEFAULT '',
            created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY email (email)
        ) $charset;";

        // Cases table
        $sql_cases = "CREATE TABLE {$wpdb->prefix}lms_cases (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            client_id       BIGINT UNSIGNED NOT NULL,
            case_number     VARCHAR(50)     NOT NULL,
            title           VARCHAR(255)    NOT NULL,
            case_type       VARCHAR(100)    DEFAULT '',
            court           VARCHAR(150)    DEFAULT '',
            judge           VARCHAR(100)    DEFAULT '',
            opposing_party  VARCHAR(150)    DEFAULT '',
            status          ENUM('open','pending','closed','won','lost') NOT NULL DEFAULT 'open',
            description     TEXT            DEFAULT '',
            filed_date      DATE            DEFAULT NULL,
            closed_date     DATE            DEFAULT NULL,
            created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY case_number (case_number),
            KEY client_id (client_id)
        ) $charset;";

        // Hearings table
        $sql_hearings = "CREATE TABLE {$wpdb->prefix}lms_hearings (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            case_id      BIGINT UNSIGNED NOT NULL,
            hearing_date DATETIME        NOT NULL,
            location     VARCHAR(200)    DEFAULT '',
            purpose      VARCHAR(255)    DEFAULT '',
            outcome      TEXT            DEFAULT '',
            next_date    DATETIME        DEFAULT NULL,
            notes        TEXT            DEFAULT '',
            created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY case_id (case_id)
        ) $charset;";

        // Documents table
        $sql_documents = "CREATE TABLE {$wpdb->prefix}lms_documents (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            case_id       BIGINT UNSIGNED NOT NULL,
            client_id     BIGINT UNSIGNED NOT NULL,
            title         VARCHAR(255)    NOT NULL,
            doc_type      VARCHAR(100)    DEFAULT '',
            file_path     VARCHAR(500)    DEFAULT '',
            file_name     VARCHAR(255)    DEFAULT '',
            file_size     BIGINT          DEFAULT 0,
            notes         TEXT            DEFAULT '',
            uploaded_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY case_id (case_id),
            KEY client_id (client_id)
        ) $charset;";

        // Invoices table
        $sql_invoices = "CREATE TABLE {$wpdb->prefix}lms_invoices (
            id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            case_id        BIGINT UNSIGNED NOT NULL,
            client_id      BIGINT UNSIGNED NOT NULL,
            invoice_number VARCHAR(50)     NOT NULL,
            amount         DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
            paid_amount    DECIMAL(12,2)   NOT NULL DEFAULT 0.00,
            status         ENUM('draft','sent','paid','partial','overdue') NOT NULL DEFAULT 'draft',
            due_date       DATE            DEFAULT NULL,
            description    TEXT            DEFAULT '',
            issued_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            paid_at        DATETIME        DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY invoice_number (invoice_number),
            KEY case_id (case_id),
            KEY client_id (client_id)
        ) $charset;";

        // Notes / activity log table
        $sql_notes = "CREATE TABLE {$wpdb->prefix}lms_notes (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            case_id    BIGINT UNSIGNED NOT NULL,
            author_id  BIGINT UNSIGNED NOT NULL,
            note       TEXT            NOT NULL,
            created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY case_id (case_id)
        ) $charset;";

        dbDelta( $sql_clients );
        dbDelta( $sql_cases );
        dbDelta( $sql_hearings );
        dbDelta( $sql_documents );
        dbDelta( $sql_invoices );
        dbDelta( $sql_notes );

        update_option( 'lms_db_version', LMS_VERSION );
    }

    public static function deactivate() {
        // Nothing to do on deactivate – tables persist
    }
}
