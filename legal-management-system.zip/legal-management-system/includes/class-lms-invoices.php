<?php
// Invoices class is defined in class-lms-documents.php
// This file intentionally left as a stub for future expansion.
if ( ! defined( 'ABSPATH' ) ) exit;
