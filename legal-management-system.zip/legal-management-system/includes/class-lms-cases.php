<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LMS_Cases {

    private $table;
    private $clients_table;

    public function __construct() {
        global $wpdb;
        $this->table         = $wpdb->prefix . 'lms_cases';
        $this->clients_table = $wpdb->prefix . 'lms_clients';
    }

    public function get_all( $args = array() ) {
        global $wpdb;
        $defaults = array(
            'search'    => '',
            'status'    => '',
            'client_id' => 0,
            'orderby'   => 'created_at',
            'order'     => 'DESC',
            'limit'     => 20,
            'offset'    => 0,
        );
        $args   = wp_parse_args( $args, $defaults );
        $where  = '1=1';
        $values = array();

        if ( ! empty( $args['search'] ) ) {
            $like    = '%' . $wpdb->esc_like( $args['search'] ) . '%';
            $where  .= ' AND (c.title LIKE %s OR c.case_number LIKE %s OR c.court LIKE %s)';
            $values[] = $like; $values[] = $like; $values[] = $like;
        }
        if ( ! empty( $args['status'] ) ) {
            $where   .= ' AND c.status = %s';
            $values[] = sanitize_key( $args['status'] );
        }
        if ( ! empty( $args['client_id'] ) ) {
            $where   .= ' AND c.client_id = %d';
            $values[] = (int) $args['client_id'];
        }

        $order   = in_array( strtoupper( $args['order'] ), array('ASC','DESC') ) ? $args['order'] : 'DESC';
        $orderby = sanitize_key( $args['orderby'] );
        $values[] = (int) $args['limit'];
        $values[] = (int) $args['offset'];

        $sql = "SELECT c.*, CONCAT(cl.first_name,' ',cl.last_name) AS client_name
                FROM {$this->table} c
                LEFT JOIN {$this->clients_table} cl ON c.client_id = cl.id
                WHERE $where ORDER BY c.$orderby $order LIMIT %d OFFSET %d";

        return $wpdb->get_results( $wpdb->prepare( $sql, $values ) );
    }

    public function count( $args = array() ) {
        global $wpdb;
        $where  = '1=1';
        $values = array();
        if ( ! empty( $args['status'] ) ) {
            $where   .= ' AND status = %s';
            $values[] = sanitize_key( $args['status'] );
        }
        $sql = "SELECT COUNT(*) FROM {$this->table} WHERE $where";
        return (int) ( $values ? $wpdb->get_var( $wpdb->prepare( $sql, $values ) ) : $wpdb->get_var( $sql ) );
    }

    public function get( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT c.*, CONCAT(cl.first_name,' ',cl.last_name) AS client_name
             FROM {$this->table} c
             LEFT JOIN {$this->clients_table} cl ON c.client_id = cl.id
             WHERE c.id = %d", $id
        ) );
    }

    public function insert( $data ) {
        global $wpdb;
        $clean = $this->sanitize( $data );
        if ( empty( $clean['case_number'] ) ) {
            $clean['case_number'] = 'CASE-' . strtoupper( wp_generate_password( 8, false ) );
        }
        $result = $wpdb->insert( $this->table, $clean );
        return $result ? $wpdb->insert_id : false;
    }

    public function update( $id, $data ) {
        global $wpdb;
        $clean = $this->sanitize( $data );
        return $wpdb->update( $this->table, $clean, array( 'id' => (int) $id ) );
    }

    public function delete( $id ) {
        global $wpdb;
        return $wpdb->delete( $this->table, array( 'id' => (int) $id ) );
    }

    public function get_statuses() {
        return array( 'open', 'pending', 'closed', 'won', 'lost' );
    }

    private function sanitize( $data ) {
        $statuses = $this->get_statuses();
        $status   = in_array( $data['status'] ?? '', $statuses ) ? $data['status'] : 'open';
        return array(
            'client_id'      => (int)  ( $data['client_id']      ?? 0 ),
            'case_number'    => sanitize_text_field( $data['case_number']    ?? '' ),
            'title'          => sanitize_text_field( $data['title']          ?? '' ),
            'case_type'      => sanitize_text_field( $data['case_type']      ?? '' ),
            'court'          => sanitize_text_field( $data['court']          ?? '' ),
            'judge'          => sanitize_text_field( $data['judge']          ?? '' ),
            'opposing_party' => sanitize_text_field( $data['opposing_party'] ?? '' ),
            'status'         => $status,
            'description'    => sanitize_textarea_field( $data['description'] ?? '' ),
            'filed_date'     => ! empty( $data['filed_date']  ) ? sanitize_text_field( $data['filed_date']  ) : null,
            'closed_date'    => ! empty( $data['closed_date'] ) ? sanitize_text_field( $data['closed_date'] ) : null,
        );
    }
}
