<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class LMS_Clients {

    private $table;

    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'lms_clients';
    }

    public function get_all( $args = array() ) {
        global $wpdb;
        $defaults = array(
            'search'  => '',
            'orderby' => 'last_name',
            'order'   => 'ASC',
            'limit'   => 20,
            'offset'  => 0,
        );
        $args = wp_parse_args( $args, $defaults );

        $where = '1=1';
        $values = array();

        if ( ! empty( $args['search'] ) ) {
            $like    = '%' . $wpdb->esc_like( $args['search'] ) . '%';
            $where  .= ' AND (first_name LIKE %s OR last_name LIKE %s OR email LIKE %s OR phone LIKE %s)';
            $values[] = $like;
            $values[] = $like;
            $values[] = $like;
            $values[] = $like;
        }

        $order   = in_array( strtoupper( $args['order'] ), array('ASC','DESC') ) ? $args['order'] : 'ASC';
        $orderby = sanitize_key( $args['orderby'] );

        $sql = "SELECT * FROM {$this->table} WHERE $where ORDER BY $orderby $order LIMIT %d OFFSET %d";
        $values[] = (int) $args['limit'];
        $values[] = (int) $args['offset'];

        return $wpdb->get_results( $wpdb->prepare( $sql, $values ) );
    }

    public function count( $search = '' ) {
        global $wpdb;
        if ( $search ) {
            $like = '%' . $wpdb->esc_like( $search ) . '%';
            return (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$this->table} WHERE first_name LIKE %s OR last_name LIKE %s OR email LIKE %s",
                $like, $like, $like
            ) );
        }
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$this->table}" );
    }

    public function get( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table} WHERE id = %d", $id ) );
    }

    public function insert( $data ) {
        global $wpdb;
        $clean = $this->sanitize( $data );
        $result = $wpdb->insert( $this->table, $clean );
        return $result ? $wpdb->insert_id : false;
    }

    public function update( $id, $data ) {
        global $wpdb;
        $clean = $this->sanitize( $data );
        return $wpdb->update( $this->table, $clean, array( 'id' => (int) $id ) );
    }

    public function delete( $id ) {
        global $wpdb;
        return $wpdb->delete( $this->table, array( 'id' => (int) $id ) );
    }

    private function sanitize( $data ) {
        return array(
            'first_name' => sanitize_text_field( $data['first_name'] ?? '' ),
            'last_name'  => sanitize_text_field( $data['last_name']  ?? '' ),
            'email'      => sanitize_email(       $data['email']      ?? '' ),
            'phone'      => sanitize_text_field( $data['phone']      ?? '' ),
            'address'    => sanitize_textarea_field( $data['address'] ?? '' ),
            'nid'        => sanitize_text_field( $data['nid']        ?? '' ),
            'notes'      => sanitize_textarea_field( $data['notes']  ?? '' ),
        );
    }
}
