<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/* =====================================================================
   Hearings
===================================================================== */
class LMS_Hearings {

    private $table;
    private $cases_table;

    public function __construct() {
        global $wpdb;
        $this->table       = $wpdb->prefix . 'lms_hearings';
        $this->cases_table = $wpdb->prefix . 'lms_cases';
    }

    public function get_by_case( $case_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$this->table} WHERE case_id = %d ORDER BY hearing_date DESC",
            (int) $case_id
        ) );
    }

    public function get_upcoming( $limit = 10 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT h.*, c.title AS case_title, c.case_number
             FROM {$this->table} h
             LEFT JOIN {$this->cases_table} c ON h.case_id = c.id
             WHERE h.hearing_date >= NOW()
             ORDER BY h.hearing_date ASC LIMIT %d",
            (int) $limit
        ) );
    }

    public function get( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table} WHERE id = %d", $id ) );
    }

    public function insert( $data ) {
        global $wpdb;
        $result = $wpdb->insert( $this->table, $this->sanitize( $data ) );
        return $result ? $wpdb->insert_id : false;
    }

    public function update( $id, $data ) {
        global $wpdb;
        return $wpdb->update( $this->table, $this->sanitize( $data ), array( 'id' => (int) $id ) );
    }

    public function delete( $id ) {
        global $wpdb;
        return $wpdb->delete( $this->table, array( 'id' => (int) $id ) );
    }

    private function sanitize( $data ) {
        return array(
            'case_id'      => (int) ( $data['case_id'] ?? 0 ),
            'hearing_date' => sanitize_text_field( $data['hearing_date'] ?? '' ),
            'location'     => sanitize_text_field( $data['location']     ?? '' ),
            'purpose'      => sanitize_text_field( $data['purpose']      ?? '' ),
            'outcome'      => sanitize_textarea_field( $data['outcome']  ?? '' ),
            'next_date'    => ! empty( $data['next_date'] ) ? sanitize_text_field( $data['next_date'] ) : null,
            'notes'        => sanitize_textarea_field( $data['notes']    ?? '' ),
        );
    }
}

/* =====================================================================
   Documents
===================================================================== */
class LMS_Documents {

    private $table;

    public function __construct() {
        global $wpdb;
        $this->table = $wpdb->prefix . 'lms_documents';
    }

    public function get_by_case( $case_id ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$this->table} WHERE case_id = %d ORDER BY uploaded_at DESC",
            (int) $case_id
        ) );
    }

    public function get( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$this->table} WHERE id = %d", $id ) );
    }

    public function insert( $data ) {
        global $wpdb;
        $result = $wpdb->insert( $this->table, $this->sanitize( $data ) );
        return $result ? $wpdb->insert_id : false;
    }

    public function delete( $id ) {
        global $wpdb;
        $doc = $this->get( $id );
        if ( $doc && $doc->file_path && file_exists( $doc->file_path ) ) {
            @unlink( $doc->file_path );
        }
        return $wpdb->delete( $this->table, array( 'id' => (int) $id ) );
    }

    private function sanitize( $data ) {
        return array(
            'case_id'   => (int) ( $data['case_id']   ?? 0 ),
            'client_id' => (int) ( $data['client_id'] ?? 0 ),
            'title'     => sanitize_text_field( $data['title']     ?? '' ),
            'doc_type'  => sanitize_text_field( $data['doc_type']  ?? '' ),
            'file_path' => sanitize_text_field( $data['file_path'] ?? '' ),
            'file_name' => sanitize_text_field( $data['file_name'] ?? '' ),
            'file_size' => (int) ( $data['file_size'] ?? 0 ),
            'notes'     => sanitize_textarea_field( $data['notes'] ?? '' ),
        );
    }
}

/* =====================================================================
   Invoices
===================================================================== */
class LMS_Invoices {

    private $table;
    private $cases_table;
    private $clients_table;

    public function __construct() {
        global $wpdb;
        $this->table         = $wpdb->prefix . 'lms_invoices';
        $this->cases_table   = $wpdb->prefix . 'lms_cases';
        $this->clients_table = $wpdb->prefix . 'lms_clients';
    }

    public function get_all( $args = array() ) {
        global $wpdb;
        $defaults = array( 'status' => '', 'limit' => 20, 'offset' => 0 );
        $args     = wp_parse_args( $args, $defaults );
        $where    = '1=1';
        $values   = array();

        if ( ! empty( $args['status'] ) ) {
            $where   .= ' AND i.status = %s';
            $values[] = sanitize_key( $args['status'] );
        }

        $values[] = (int) $args['limit'];
        $values[] = (int) $args['offset'];

        $sql = "SELECT i.*,
                       CONCAT(cl.first_name,' ',cl.last_name) AS client_name,
                       ca.title AS case_title
                FROM {$this->table} i
                LEFT JOIN {$this->clients_table} cl ON i.client_id = cl.id
                LEFT JOIN {$this->cases_table}   ca ON i.case_id   = ca.id
                WHERE $where ORDER BY i.issued_at DESC LIMIT %d OFFSET %d";

        return $wpdb->get_results( $wpdb->prepare( $sql, $values ) );
    }

    public function get( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT i.*,
                    CONCAT(cl.first_name,' ',cl.last_name) AS client_name,
                    ca.title AS case_title
             FROM {$this->table} i
             LEFT JOIN {$this->clients_table} cl ON i.client_id = cl.id
             LEFT JOIN {$this->cases_table}   ca ON i.case_id   = ca.id
             WHERE i.id = %d", $id
        ) );
    }

    public function insert( $data ) {
        global $wpdb;
        $clean = $this->sanitize( $data );
        if ( empty( $clean['invoice_number'] ) ) {
            $clean['invoice_number'] = 'INV-' . date('Ymd') . '-' . rand(100,999);
        }
        $result = $wpdb->insert( $this->table, $clean );
        return $result ? $wpdb->insert_id : false;
    }

    public function update( $id, $data ) {
        global $wpdb;
        return $wpdb->update( $this->table, $this->sanitize( $data ), array( 'id' => (int) $id ) );
    }

    public function delete( $id ) {
        global $wpdb;
        return $wpdb->delete( $this->table, array( 'id' => (int) $id ) );
    }

    public function get_totals() {
        global $wpdb;
        return $wpdb->get_row(
            "SELECT
                SUM(amount)      AS total_billed,
                SUM(paid_amount) AS total_paid,
                SUM(amount - paid_amount) AS total_outstanding
             FROM {$this->table}"
        );
    }

    private function sanitize( $data ) {
        $statuses = array('draft','sent','paid','partial','overdue');
        $status   = in_array( $data['status'] ?? '', $statuses ) ? $data['status'] : 'draft';
        return array(
            'case_id'        => (int)   ( $data['case_id']        ?? 0 ),
            'client_id'      => (int)   ( $data['client_id']      ?? 0 ),
            'invoice_number' => sanitize_text_field( $data['invoice_number'] ?? '' ),
            'amount'         => (float) ( $data['amount']         ?? 0 ),
            'paid_amount'    => (float) ( $data['paid_amount']    ?? 0 ),
            'status'         => $status,
            'due_date'       => ! empty( $data['due_date'] ) ? sanitize_text_field( $data['due_date'] ) : null,
            'description'    => sanitize_textarea_field( $data['description'] ?? '' ),
            'paid_at'        => ! empty( $data['paid_at'] ) ? sanitize_text_field( $data['paid_at'] ) : null,
        );
    }
}
