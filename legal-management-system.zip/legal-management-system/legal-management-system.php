<?php

/**
 * Plugin Name: Legal Management System
 * Plugin URI:  https://github.com/MustafijurBiplob/legal-case-management-system-for-lawyers
 * Description: A comprehensive legal case management system for lawyers, law firms, and legal professionals. Manage clients, cases, documents, hearings, and invoices directly from your WordPress dashboard.
 * Version:     1.0.0
 * Author:      Mustafijur Rahman
 * Author URI:  https://github.com/MustafijurBiplob
 * License:     GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: legal-management-system
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.2
 * Tested up to: 6.4
 * Stable tag: 1.0.0
 *
 * @package LegalManagementSystem
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Define plugin constants
define( 'LMS_VERSION', '1.0.0' );
define( 'LMS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'LMS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'LMS_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );

// Include required files
require_once LMS_PLUGIN_DIR . 'includes/class-lms-db.php';
require_once LMS_PLUGIN_DIR . 'includes/class-lms-clients.php';
require_once LMS_PLUGIN_DIR . 'includes/class-lms-cases.php';
require_once LMS_PLUGIN_DIR . 'includes/class-lms-documents.php';
require_once LMS_PLUGIN_DIR . 'includes/class-lms-hearings.php';
require_once LMS_PLUGIN_DIR . 'includes/class-lms-invoices.php';
require_once LMS_PLUGIN_DIR . 'includes/class-lms-admin.php';

// Activation and deactivation hooks
register_activation_hook( __FILE__, array( 'LMS_DB', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'LMS_DB', 'deactivate' ) );

// Initialize plugin
add_action( 'plugins_loaded', 'lms_init' );

/**
 * Initialize the plugin
 */
function lms_init() {
    // Load text domain for translations
    load_plugin_textdomain( 'legal-management-system', false, dirname( LMS_PLUGIN_BASENAME ) . '/languages' );
    
    // Initialize admin
    new LMS_Admin();
}