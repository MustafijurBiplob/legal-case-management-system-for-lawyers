/* Legal Management System — Admin JS */
(function ($) {
    'use strict';

    /* ----------------------------------------------------------------
       Modal helpers
    ---------------------------------------------------------------- */
    function openModal(id) {
        $('#' + id).addClass('active');
        $('body').css('overflow', 'hidden');
    }

    function closeModal(id) {
        $('#' + id).removeClass('active');
        $('body').css('overflow', '');
        $('#' + id + ' form')[0]?.reset();
        $('#' + id + ' .lms-alert').remove();
    }

    $(document).on('click', '.lms-modal-close, .lms-modal-cancel', function () {
        $(this).closest('.lms-modal-overlay').removeClass('active');
        $('body').css('overflow', '');
    });

    $(document).on('click', '.lms-modal-overlay', function (e) {
        if ($(e.target).hasClass('lms-modal-overlay')) {
            $(this).removeClass('active');
            $('body').css('overflow', '');
        }
    });

    /* ----------------------------------------------------------------
       Alert injection
    ---------------------------------------------------------------- */
    function showAlert(container, type, msg) {
        $(container).find('.lms-alert').remove();
        var icon = type === 'success' ? '✓' : '✗';
        var html = '<div class="lms-alert lms-alert-' + type + '">' + icon + ' ' + msg + '</div>';
        $(container).prepend(html);
    }

    /* ----------------------------------------------------------------
       Generic AJAX form submit
    ---------------------------------------------------------------- */
    function ajaxForm($form, action, onSuccess) {
        var data = $form.serializeArray();
        data.push({ name: 'action', value: action });
        data.push({ name: 'nonce',  value: LMS.nonce });

        var $btn = $form.find('[type="submit"]');
        $btn.prop('disabled', true).text('Saving…');

        $.post(LMS.ajax_url, data, function (res) {
            if (res.success) {
                onSuccess(res.data);
            } else {
                showAlert($form, 'error', res.data || 'An error occurred.');
                $btn.prop('disabled', false).text('Save');
            }
        }).fail(function () {
            showAlert($form, 'error', 'Network error. Please try again.');
            $btn.prop('disabled', false).text('Save');
        });
    }

    /* ----------------------------------------------------------------
       Clients
    ---------------------------------------------------------------- */
    $('#lms-add-client-btn').on('click', function () {
        $('#lms-client-modal').find('input,textarea,select').val('');
        $('#lms-client-id').val(0);
        $('#lms-client-modal .lms-modal-header h3').text('Add Client');
        openModal('lms-client-modal');
    });

    $(document).on('click', '.lms-edit-client', function () {
        var id        = $(this).data('id');
        var row       = $(this).closest('tr');
        $('#lms-client-id').val(id);
        $('#lms-client-first-name').val(row.data('first-name'));
        $('#lms-client-last-name').val(row.data('last-name'));
        $('#lms-client-email').val(row.data('email'));
        $('#lms-client-phone').val(row.data('phone'));
        $('#lms-client-nid').val(row.data('nid'));
        $('#lms-client-address').val(row.data('address'));
        $('#lms-client-notes').val(row.data('notes'));
        $('#lms-client-modal .lms-modal-header h3').text('Edit Client');
        openModal('lms-client-modal');
    });

    $('#lms-client-form').on('submit', function (e) {
        e.preventDefault();
        ajaxForm($(this), 'lms_save_client', function (data) {
            location.reload();
        });
    });

    $(document).on('click', '.lms-delete-client', function () {
        if (!confirm('Delete this client? This cannot be undone.')) return;
        var id = $(this).data('id');
        $.post(LMS.ajax_url, { action: 'lms_delete_client', id: id, nonce: LMS.nonce }, function (res) {
            res.success ? location.reload() : alert('Delete failed.');
        });
    });

    /* ----------------------------------------------------------------
       Cases
    ---------------------------------------------------------------- */
    $('#lms-add-case-btn').on('click', function () {
        $('#lms-case-form')[0].reset();
        $('#lms-case-id').val(0);
        $('#lms-case-modal .lms-modal-header h3').text('New Case');
        openModal('lms-case-modal');
    });

    $(document).on('click', '.lms-edit-case', function () {
        var d = $(this).data();
        $('#lms-case-id').val(d.id);
        $('#lms-case-client').val(d.clientId);
        $('#lms-case-number').val(d.caseNumber);
        $('#lms-case-title').val(d.title);
        $('#lms-case-type').val(d.caseType);
        $('#lms-case-court').val(d.court);
        $('#lms-case-judge').val(d.judge);
        $('#lms-case-opposing').val(d.opposing);
        $('#lms-case-status').val(d.status);
        $('#lms-case-filed').val(d.filed);
        $('#lms-case-description').val(d.description);
        $('#lms-case-modal .lms-modal-header h3').text('Edit Case');
        openModal('lms-case-modal');
    });

    $('#lms-case-form').on('submit', function (e) {
        e.preventDefault();
        ajaxForm($(this), 'lms_save_case', function () { location.reload(); });
    });

    $(document).on('click', '.lms-delete-case', function () {
        if (!confirm('Delete this case and all related records?')) return;
        var id = $(this).data('id');
        $.post(LMS.ajax_url, { action: 'lms_delete_case', id: id, nonce: LMS.nonce }, function (res) {
            res.success ? location.reload() : alert('Delete failed.');
        });
    });

    /* ----------------------------------------------------------------
       Hearings
    ---------------------------------------------------------------- */
    $('#lms-add-hearing-btn').on('click', function () {
        $('#lms-hearing-form')[0].reset();
        $('#lms-hearing-id').val(0);
        openModal('lms-hearing-modal');
    });

    $('#lms-hearing-form').on('submit', function (e) {
        e.preventDefault();
        ajaxForm($(this), 'lms_save_hearing', function () { location.reload(); });
    });

    /* ----------------------------------------------------------------
       Invoices
    ---------------------------------------------------------------- */
    $('#lms-add-invoice-btn').on('click', function () {
        $('#lms-invoice-form')[0].reset();
        $('#lms-invoice-id').val(0);
        openModal('lms-invoice-modal');
    });

    $('#lms-invoice-form').on('submit', function (e) {
        e.preventDefault();
        ajaxForm($(this), 'lms_save_invoice', function () { location.reload(); });
    });

    /* ----------------------------------------------------------------
       Filter tabs
    ---------------------------------------------------------------- */
    $(document).on('click', '.lms-filter-tab', function (e) {
        e.preventDefault();
        var url = new URL(window.location.href);
        url.searchParams.set('status', $(this).data('status'));
        window.location.href = url.toString();
    });

    /* ----------------------------------------------------------------
       Search on enter
    ---------------------------------------------------------------- */
    $('.lms-search-box input').on('keydown', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            $(this).closest('.lms-search-box').find('button').trigger('click');
        }
    });

    $('.lms-search-box button').on('click', function () {
        var q   = $(this).prev('input').val();
        var url = new URL(window.location.href);
        url.searchParams.set('s', q);
        window.location.href = url.toString();
    });

}(jQuery));
