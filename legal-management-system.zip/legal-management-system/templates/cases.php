<?php if ( ! defined('ABSPATH') ) exit; ?>
<div class="lms-wrap">

    <div class="lms-header">
        <h1><span class="dashicons dashicons-portfolio"></span> Cases</h1>
        <button id="lms-add-case-btn" class="lms-btn lms-btn-primary">+ New Case</button>
    </div>

    <!-- Status tabs -->
    <div class="lms-tabs">
        <?php
        $statuses_tabs = array('' => 'All', 'open' => 'Open', 'pending' => 'Pending', 'closed' => 'Closed', 'won' => 'Won', 'lost' => 'Lost');
        foreach ( $statuses_tabs as $key => $label ) :
            $active = ($status === $key) ? 'active' : '';
        ?>
        <a href="<?php echo admin_url('admin.php?page=lms-cases&status='.urlencode($key)); ?>" class="lms-tab <?php echo esc_attr($active); ?>"><?php echo esc_html($label); ?></a>
        <?php endforeach; ?>
    </div>

    <div class="lms-card">
        <div class="lms-card-header">
            <span>Cases</span>
            <div class="lms-search-box">
                <input type="search" placeholder="Search cases…" value="<?php echo esc_attr($search); ?>">
                <button>🔍</button>
            </div>
        </div>
        <div class="lms-card-body" style="padding:0;">
            <?php if ( empty($cases) ) : ?>
                <div class="lms-empty"><div class="dashicons dashicons-portfolio"></div><p>No cases found.</p></div>
            <?php else : ?>
            <table class="lms-table">
                <thead>
                    <tr>
                        <th>Case No.</th>
                        <th>Title</th>
                        <th>Client</th>
                        <th>Court</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Filed</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ( $cases as $c ) : ?>
                    <tr>
                        <td><code><?php echo esc_html($c->case_number); ?></code></td>
                        <td><strong><?php echo esc_html($c->title); ?></strong></td>
                        <td><?php echo esc_html($c->client_name); ?></td>
                        <td><?php echo esc_html($c->court); ?></td>
                        <td><?php echo esc_html($c->case_type); ?></td>
                        <td><span class="lms-badge badge-<?php echo esc_attr($c->status); ?>"><?php echo esc_html($c->status); ?></span></td>
                        <td><?php echo $c->filed_date ? esc_html(date('d M Y', strtotime($c->filed_date))) : '—'; ?></td>
                        <td>
                            <div class="row-actions">
                                <button class="lms-btn lms-btn-sm lms-btn-outline lms-edit-case"
                                    data-id="<?php echo (int)$c->id; ?>"
                                    data-client-id="<?php echo (int)$c->client_id; ?>"
                                    data-case-number="<?php echo esc_attr($c->case_number); ?>"
                                    data-title="<?php echo esc_attr($c->title); ?>"
                                    data-case-type="<?php echo esc_attr($c->case_type); ?>"
                                    data-court="<?php echo esc_attr($c->court); ?>"
                                    data-judge="<?php echo esc_attr($c->judge); ?>"
                                    data-opposing="<?php echo esc_attr($c->opposing_party); ?>"
                                    data-status="<?php echo esc_attr($c->status); ?>"
                                    data-filed="<?php echo esc_attr($c->filed_date); ?>"
                                    data-description="<?php echo esc_attr($c->description); ?>">Edit</button>
                                <button class="lms-btn lms-btn-sm lms-btn-danger lms-delete-case" data-id="<?php echo (int)$c->id; ?>">Delete</button>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Case Modal -->
<div id="lms-case-modal" class="lms-modal-overlay">
    <div class="lms-modal">
        <div class="lms-modal-header">
            <h3>New Case</h3>
            <button class="lms-modal-close">&times;</button>
        </div>
        <form id="lms-case-form">
            <input type="hidden" name="id" id="lms-case-id" value="0">
            <div class="lms-modal-body">
                <div class="lms-form-row">
                    <div class="lms-form-group">
                        <label>Client *</label>
                        <select name="client_id" id="lms-case-client" required>
                            <option value="">— Select Client —</option>
                            <?php foreach ( $clients_list as $cl ) : ?>
                            <option value="<?php echo (int)$cl->id; ?>"><?php echo esc_html($cl->first_name.' '.$cl->last_name); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="lms-form-group">
                        <label>Case Number</label>
                        <input type="text" name="case_number" id="lms-case-number" placeholder="Auto-generated if empty">
                    </div>
                </div>
                <div class="lms-form-row single">
                    <div class="lms-form-group">
                        <label>Case Title *</label>
                        <input type="text" name="title" id="lms-case-title" required>
                    </div>
                </div>
                <div class="lms-form-row">
                    <div class="lms-form-group">
                        <label>Case Type</label>
                        <select name="case_type" id="lms-case-type">
                            <option value="">— Select —</option>
                            <option>Criminal</option>
                            <option>Civil</option>
                            <option>Family</option>
                            <option>Corporate</option>
                            <option>Property</option>
                            <option>Labour</option>
                            <option>Tax</option>
                            <option>Other</option>
                        </select>
                    </div>
                    <div class="lms-form-group">
                        <label>Status</label>
                        <select name="status" id="lms-case-status">
                            <option value="open">Open</option>
                            <option value="pending">Pending</option>
                            <option value="closed">Closed</option>
                            <option value="won">Won</option>
                            <option value="lost">Lost</option>
                        </select>
                    </div>
                </div>
                <div class="lms-form-row">
                    <div class="lms-form-group">
                        <label>Court</label>
                        <input type="text" name="court" id="lms-case-court">
                    </div>
                    <div class="lms-form-group">
                        <label>Judge</label>
                        <input type="text" name="judge" id="lms-case-judge">
                    </div>
                </div>
                <div class="lms-form-row">
                    <div class="lms-form-group">
                        <label>Opposing Party</label>
                        <input type="text" name="opposing_party" id="lms-case-opposing">
                    </div>
                    <div class="lms-form-group">
                        <label>Filed Date</label>
                        <input type="date" name="filed_date" id="lms-case-filed">
                    </div>
                </div>
                <div class="lms-form-row single">
                    <div class="lms-form-group">
                        <label>Description</label>
                        <textarea name="description" id="lms-case-description"></textarea>
                    </div>
                </div>
            </div>
            <div class="lms-modal-footer">
                <button type="button" class="lms-btn lms-btn-outline lms-modal-cancel">Cancel</button>
                <button type="submit" class="lms-btn lms-btn-primary">Save Case</button>
            </div>
        </form>
    </div>
</div>
