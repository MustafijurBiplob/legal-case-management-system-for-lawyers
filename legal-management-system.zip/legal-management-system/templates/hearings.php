<?php if ( ! defined('ABSPATH') ) exit;
// This file contains: hearings.php, documents.php, invoices.php
// WordPress will include only the correct one via page routing.
// Each template is wrapped in a page guard below.
?>
<?php
// Hearings page
?>
<div class="lms-wrap">
    <div class="lms-header">
        <h1><span class="dashicons dashicons-calendar-alt"></span> Hearings</h1>
        <button id="lms-add-hearing-btn" class="lms-btn lms-btn-primary">+ Schedule Hearing</button>
    </div>

    <div class="lms-card">
        <div class="lms-card-header">Upcoming &amp; Recent Hearings</div>
        <div class="lms-card-body" style="padding:0;">
            <?php if ( empty($upcoming) ) : ?>
                <div class="lms-empty"><div class="dashicons dashicons-calendar-alt"></div><p>No hearings scheduled.</p></div>
            <?php else : ?>
            <table class="lms-table">
                <thead>
                    <tr><th>Date &amp; Time</th><th>Case</th><th>Location</th><th>Purpose</th><th>Outcome</th><th>Next Date</th></tr>
                </thead>
                <tbody>
                <?php foreach ( $upcoming as $h ) : ?>
                <tr>
                    <td><strong><?php echo esc_html(date('d M Y', strtotime($h->hearing_date))); ?></strong><br><small><?php echo esc_html(date('H:i', strtotime($h->hearing_date))); ?></small></td>
                    <td><?php echo esc_html($h->case_title ?? '—'); ?><br><small><code><?php echo esc_html($h->case_number ?? ''); ?></code></small></td>
                    <td><?php echo esc_html($h->location); ?></td>
                    <td><?php echo esc_html($h->purpose); ?></td>
                    <td><?php echo esc_html($h->outcome ?: '—'); ?></td>
                    <td><?php echo $h->next_date ? esc_html(date('d M Y', strtotime($h->next_date))) : '—'; ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Hearing Modal -->
<div id="lms-hearing-modal" class="lms-modal-overlay">
    <div class="lms-modal">
        <div class="lms-modal-header">
            <h3>Schedule Hearing</h3>
            <button class="lms-modal-close">&times;</button>
        </div>
        <form id="lms-hearing-form">
            <input type="hidden" name="id" id="lms-hearing-id" value="0">
            <div class="lms-modal-body">
                <div class="lms-form-row single">
                    <div class="lms-form-group">
                        <label>Case *</label>
                        <select name="case_id" required>
                            <option value="">— Select Case —</option>
                            <?php foreach ( $cases_list as $c ) : ?>
                            <option value="<?php echo (int)$c->id; ?>">[<?php echo esc_html($c->case_number); ?>] <?php echo esc_html($c->title); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="lms-form-row">
                    <div class="lms-form-group">
                        <label>Hearing Date &amp; Time *</label>
                        <input type="datetime-local" name="hearing_date" required>
                    </div>
                    <div class="lms-form-group">
                        <label>Next Hearing Date</label>
                        <input type="datetime-local" name="next_date">
                    </div>
                </div>
                <div class="lms-form-row">
                    <div class="lms-form-group">
                        <label>Location / Court Room</label>
                        <input type="text" name="location">
                    </div>
                    <div class="lms-form-group">
                        <label>Purpose</label>
                        <input type="text" name="purpose" placeholder="e.g. Bail hearing, Arguments">
                    </div>
                </div>
                <div class="lms-form-row single">
                    <div class="lms-form-group">
                        <label>Outcome / Notes</label>
                        <textarea name="outcome"></textarea>
                    </div>
                </div>
            </div>
            <div class="lms-modal-footer">
                <button type="button" class="lms-btn lms-btn-outline lms-modal-cancel">Cancel</button>
                <button type="submit" class="lms-btn lms-btn-primary">Save Hearing</button>
            </div>
        </form>
    </div>
</div>
