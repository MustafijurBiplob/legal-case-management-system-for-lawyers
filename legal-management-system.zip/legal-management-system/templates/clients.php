<?php if ( ! defined('ABSPATH') ) exit; ?>
<div class="lms-wrap">

    <div class="lms-header">
        <h1><span class="dashicons dashicons-groups"></span> Clients</h1>
        <button id="lms-add-client-btn" class="lms-btn lms-btn-primary">+ Add Client</button>
    </div>

    <div class="lms-card">
        <div class="lms-card-header">
            <span>All Clients (<?php echo esc_html($this->clients->count($search)); ?>)</span>
            <div class="lms-search-box">
                <input type="search" placeholder="Search clients…" value="<?php echo esc_attr($search); ?>">
                <button>🔍</button>
            </div>
        </div>
        <div class="lms-card-body" style="padding:0;">
            <?php if ( empty($clients) ) : ?>
                <div class="lms-empty"><div class="dashicons dashicons-groups"></div><p>No clients found. Add your first client.</p></div>
            <?php else : ?>
            <table class="lms-table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>NID</th>
                        <th>Added</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ( $clients as $c ) : ?>
                    <tr data-first-name="<?php echo esc_attr($c->first_name); ?>"
                        data-last-name="<?php echo esc_attr($c->last_name); ?>"
                        data-email="<?php echo esc_attr($c->email); ?>"
                        data-phone="<?php echo esc_attr($c->phone); ?>"
                        data-nid="<?php echo esc_attr($c->nid); ?>"
                        data-address="<?php echo esc_attr($c->address); ?>"
                        data-notes="<?php echo esc_attr($c->notes); ?>">
                        <td><?php echo (int)$c->id; ?></td>
                        <td><strong><?php echo esc_html($c->first_name . ' ' . $c->last_name); ?></strong></td>
                        <td><?php echo esc_html($c->email); ?></td>
                        <td><?php echo esc_html($c->phone); ?></td>
                        <td><?php echo esc_html($c->nid); ?></td>
                        <td><?php echo esc_html(date('d M Y', strtotime($c->created_at))); ?></td>
                        <td>
                            <div class="row-actions">
                                <button class="lms-btn lms-btn-sm lms-btn-outline lms-edit-client" data-id="<?php echo (int)$c->id; ?>">Edit</button>
                                <button class="lms-btn lms-btn-sm lms-btn-danger lms-delete-client" data-id="<?php echo (int)$c->id; ?>">Delete</button>
                                <a href="<?php echo admin_url('admin.php?page=lms-cases&client_id='.(int)$c->id); ?>" class="lms-btn lms-btn-sm lms-btn-primary">Cases</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Client Modal -->
<div id="lms-client-modal" class="lms-modal-overlay">
    <div class="lms-modal">
        <div class="lms-modal-header">
            <h3>Add Client</h3>
            <button class="lms-modal-close">&times;</button>
        </div>
        <form id="lms-client-form">
            <input type="hidden" name="id" id="lms-client-id" value="0">
            <div class="lms-modal-body">
                <div class="lms-form-row">
                    <div class="lms-form-group">
                        <label>First Name *</label>
                        <input type="text" name="first_name" id="lms-client-first-name" required>
                    </div>
                    <div class="lms-form-group">
                        <label>Last Name *</label>
                        <input type="text" name="last_name" id="lms-client-last-name" required>
                    </div>
                </div>
                <div class="lms-form-row">
                    <div class="lms-form-group">
                        <label>Email *</label>
                        <input type="email" name="email" id="lms-client-email" required>
                    </div>
                    <div class="lms-form-group">
                        <label>Phone</label>
                        <input type="text" name="phone" id="lms-client-phone">
                    </div>
                </div>
                <div class="lms-form-row">
                    <div class="lms-form-group">
                        <label>NID / Passport</label>
                        <input type="text" name="nid" id="lms-client-nid">
                    </div>
                </div>
                <div class="lms-form-row single">
                    <div class="lms-form-group">
                        <label>Address</label>
                        <textarea name="address" id="lms-client-address"></textarea>
                    </div>
                </div>
                <div class="lms-form-row single">
                    <div class="lms-form-group">
                        <label>Notes</label>
                        <textarea name="notes" id="lms-client-notes"></textarea>
                    </div>
                </div>
            </div>
            <div class="lms-modal-footer">
                <button type="button" class="lms-btn lms-btn-outline lms-modal-cancel">Cancel</button>
                <button type="submit" class="lms-btn lms-btn-primary">Save Client</button>
            </div>
        </form>
    </div>
</div>
