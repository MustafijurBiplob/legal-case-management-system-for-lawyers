<?php if ( ! defined('ABSPATH') ) exit; ?>
<div class="lms-wrap">
    <div class="lms-header">
        <h1><span class="dashicons dashicons-media-document"></span> Documents</h1>
    </div>
    <div class="lms-card">
        <div class="lms-card-header">Document Manager</div>
        <div class="lms-card-body">
            <p style="color:var(--lms-muted);font-size:13px;">
                Documents are managed per-case. Open a case and use the <strong>Documents</strong> tab to upload, view, and delete files linked to that case.
            </p>
            <a href="<?php echo admin_url('admin.php?page=lms-cases'); ?>" class="lms-btn lms-btn-primary">Go to Cases →</a>
        </div>
    </div>
</div>
