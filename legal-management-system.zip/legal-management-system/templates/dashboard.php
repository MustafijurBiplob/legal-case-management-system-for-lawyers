<?php if ( ! defined('ABSPATH') ) exit; ?>
<div class="lms-wrap">

    <div class="lms-header">
        <h1><span class="dashicons dashicons-hammer"></span> Legal Management System</h1>
        <span style="font-size:12px;color:#6b7280;">Welcome, <?php echo esc_html( wp_get_current_user()->display_name ); ?></span>
    </div>

    <!-- Stats -->
    <div class="lms-stats">
        <div class="lms-stat-card">
            <div class="stat-number"><?php echo esc_html($total_clients); ?></div>
            <div class="stat-label">Total Clients</div>
        </div>
        <div class="lms-stat-card accent">
            <div class="stat-number"><?php echo esc_html($total_cases); ?></div>
            <div class="stat-label">Total Cases</div>
        </div>
        <div class="lms-stat-card info">
            <div class="stat-number"><?php echo esc_html($total_open); ?></div>
            <div class="stat-label">Open Cases</div>
        </div>
        <div class="lms-stat-card success">
            <div class="stat-number">৳<?php echo number_format( (float)($totals->total_paid ?? 0), 0 ); ?></div>
            <div class="stat-label">Total Collected</div>
        </div>
        <div class="lms-stat-card warning">
            <div class="stat-number">৳<?php echo number_format( (float)($totals->total_outstanding ?? 0), 0 ); ?></div>
            <div class="stat-label">Outstanding</div>
        </div>
    </div>

    <!-- Main grid -->
    <div class="lms-dashboard-grid">

        <!-- Upcoming hearings -->
        <div class="lms-card">
            <div class="lms-card-header">
                <span>⚖️ Upcoming Hearings</span>
                <a href="<?php echo admin_url('admin.php?page=lms-hearings'); ?>" class="lms-btn lms-btn-sm" style="background:rgba(255,255,255,.15);color:#fff;">View All</a>
            </div>
            <div class="lms-card-body">
                <?php if ( empty($upcoming) ) : ?>
                    <div class="lms-empty"><div class="dashicons dashicons-calendar-alt"></div><p>No upcoming hearings scheduled.</p></div>
                <?php else : ?>
                    <ul class="lms-upcoming-list">
                    <?php foreach ( $upcoming as $h ) :
                        $dt = new DateTime($h->hearing_date);
                    ?>
                        <li>
                            <div class="lms-upcoming-date">
                                <?php echo esc_html($dt->format('d')); ?><br>
                                <?php echo esc_html($dt->format('M')); ?>
                            </div>
                            <div>
                                <strong><?php echo esc_html($h->case_title ?? 'Case'); ?></strong><br>
                                <span style="color:var(--lms-muted);font-size:12px;"><?php echo esc_html($h->purpose); ?> &bull; <?php echo esc_html($h->location); ?></span>
                            </div>
                        </li>
                    <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>

        <!-- Quick links -->
        <div>
            <div class="lms-card">
                <div class="lms-card-header">Quick Actions</div>
                <div class="lms-card-body" style="display:flex;flex-direction:column;gap:10px;">
                    <a href="<?php echo admin_url('admin.php?page=lms-clients'); ?>" class="lms-btn lms-btn-primary">👤 Add New Client</a>
                    <a href="<?php echo admin_url('admin.php?page=lms-cases'); ?>"   class="lms-btn lms-btn-accent">📁 Open New Case</a>
                    <a href="<?php echo admin_url('admin.php?page=lms-hearings'); ?>" class="lms-btn lms-btn-outline">📅 Schedule Hearing</a>
                    <a href="<?php echo admin_url('admin.php?page=lms-invoices'); ?>" class="lms-btn lms-btn-outline">🧾 Create Invoice</a>
                </div>
            </div>
        </div>
    </div>
</div>
