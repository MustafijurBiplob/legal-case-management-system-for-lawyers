<?php if ( ! defined('ABSPATH') ) exit; ?>
<div class="lms-wrap">

    <div class="lms-header">
        <h1><span class="dashicons dashicons-money-alt"></span> Invoices</h1>
        <button id="lms-add-invoice-btn" class="lms-btn lms-btn-primary">+ Create Invoice</button>
    </div>

    <!-- Totals -->
    <div class="lms-stats">
        <div class="lms-stat-card">
            <div class="stat-number">৳<?php echo number_format((float)($totals->total_billed ?? 0), 0); ?></div>
            <div class="stat-label">Total Billed</div>
        </div>
        <div class="lms-stat-card success">
            <div class="stat-number">৳<?php echo number_format((float)($totals->total_paid ?? 0), 0); ?></div>
            <div class="stat-label">Collected</div>
        </div>
        <div class="lms-stat-card warning">
            <div class="stat-number">৳<?php echo number_format((float)($totals->total_outstanding ?? 0), 0); ?></div>
            <div class="stat-label">Outstanding</div>
        </div>
    </div>

    <!-- Filter tabs -->
    <div class="lms-tabs">
        <?php foreach ( array('' => 'All', 'draft' => 'Draft', 'sent' => 'Sent', 'paid' => 'Paid', 'partial' => 'Partial', 'overdue' => 'Overdue') as $k => $l ) :
            $active = ($status === $k) ? 'active' : '';
        ?>
        <a href="<?php echo admin_url('admin.php?page=lms-invoices&status='.urlencode($k)); ?>" class="lms-tab <?php echo esc_attr($active); ?>"><?php echo esc_html($l); ?></a>
        <?php endforeach; ?>
    </div>

    <div class="lms-card">
        <div class="lms-card-header">Invoices</div>
        <div class="lms-card-body" style="padding:0;">
            <?php if ( empty($invoices) ) : ?>
                <div class="lms-empty"><div class="dashicons dashicons-money-alt"></div><p>No invoices found.</p></div>
            <?php else : ?>
            <table class="lms-table">
                <thead>
                    <tr><th>Invoice #</th><th>Client</th><th>Case</th><th>Amount</th><th>Paid</th><th>Status</th><th>Due</th></tr>
                </thead>
                <tbody>
                <?php foreach ( $invoices as $inv ) : ?>
                <tr>
                    <td><code><?php echo esc_html($inv->invoice_number); ?></code></td>
                    <td><?php echo esc_html($inv->client_name); ?></td>
                    <td><?php echo esc_html($inv->case_title); ?></td>
                    <td>৳<?php echo number_format((float)$inv->amount, 2); ?></td>
                    <td>৳<?php echo number_format((float)$inv->paid_amount, 2); ?></td>
                    <td><span class="lms-badge badge-<?php echo esc_attr($inv->status); ?>"><?php echo esc_html($inv->status); ?></span></td>
                    <td><?php echo $inv->due_date ? esc_html(date('d M Y', strtotime($inv->due_date))) : '—'; ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Invoice Modal -->
<div id="lms-invoice-modal" class="lms-modal-overlay">
    <div class="lms-modal">
        <div class="lms-modal-header">
            <h3>Create Invoice</h3>
            <button class="lms-modal-close">&times;</button>
        </div>
        <form id="lms-invoice-form">
            <input type="hidden" name="id" id="lms-invoice-id" value="0">
            <div class="lms-modal-body">
                <div class="lms-form-row">
                    <div class="lms-form-group">
                        <label>Client *</label>
                        <select name="client_id" required>
                            <option value="">— Select Client —</option>
                            <?php foreach ( $clients_list as $cl ) : ?>
                            <option value="<?php echo (int)$cl->id; ?>"><?php echo esc_html($cl->first_name.' '.$cl->last_name); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="lms-form-group">
                        <label>Case *</label>
                        <select name="case_id" required>
                            <option value="">— Select Case —</option>
                            <?php foreach ( $cases_list as $c ) : ?>
                            <option value="<?php echo (int)$c->id; ?>"><?php echo esc_html($c->title); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="lms-form-row">
                    <div class="lms-form-group">
                        <label>Amount (৳) *</label>
                        <input type="number" name="amount" step="0.01" min="0" required>
                    </div>
                    <div class="lms-form-group">
                        <label>Amount Paid (৳)</label>
                        <input type="number" name="paid_amount" step="0.01" min="0" value="0">
                    </div>
                </div>
                <div class="lms-form-row">
                    <div class="lms-form-group">
                        <label>Status</label>
                        <select name="status">
                            <option value="draft">Draft</option>
                            <option value="sent">Sent</option>
                            <option value="paid">Paid</option>
                            <option value="partial">Partial</option>
                            <option value="overdue">Overdue</option>
                        </select>
                    </div>
                    <div class="lms-form-group">
                        <label>Due Date</label>
                        <input type="date" name="due_date">
                    </div>
                </div>
                <div class="lms-form-row single">
                    <div class="lms-form-group">
                        <label>Description / Services</label>
                        <textarea name="description"></textarea>
                    </div>
                </div>
            </div>
            <div class="lms-modal-footer">
                <button type="button" class="lms-btn lms-btn-outline lms-modal-cancel">Cancel</button>
                <button type="submit" class="lms-btn lms-btn-primary">Save Invoice</button>
            </div>
        </form>
    </div>
</div>
